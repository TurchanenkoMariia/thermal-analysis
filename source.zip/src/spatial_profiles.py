import numpy as np
import pandas as pd
import streamlit as st

METRICS = {"Середня": "mean_temperature", "Мінімум": "min_temperature",
           "Медіана": "median_temperature", "Максимум": "max_temperature"}
HISTORY = {"Середня": "Середня, °C", "Мінімум": "Мінімум, °C",
           "Медіана": "Медіана, °C", "Максимум": "Максимум, °C"}

def profile(matrix, mask, axis):
    y, x = np.nonzero(mask)
    coord = x if axis == "X" else y if axis == "Y" else np.floor(
        np.hypot(x - x.mean(), y - y.mean())).astype(int)
    groups = pd.DataFrame({"p": coord, "t": matrix[y, x]}).groupby("p")["t"]
    return groups.agg(["mean", "min", "median", "max", "count"]).set_axis(
        [*METRICS, "Пікселів"], axis=1)

def distribution(result, selected, names):
    st.subheader("Розподіл температур")
    k = result.analysis_id
    region = st.selectbox("Область для профілю", selected, format_func=lambda v: names[v], key="pr_area"+k)
    axis = st.radio("Напрям профілю", ["X", "Y", "Радіально"], horizontal=True, key="pr_axis"+k)
    metrics = st.multiselect("Показники профілю", list(METRICS), default=["Медіана"], key="pr_metrics"+k)
    if not metrics:
        st.info("Виберіть хоча б один показник.")
        return
    table = profile(result.thermal.temperatures, result.regions[region], axis)
    table.index.name = {"X":"Стовпець X, пікс.", "Y":"Рядок Y, пікс.", "Радіально":"Радіус, пікс."}[axis]
    st.caption({"X":"Кожна позиція — стовпець зліва направо.", "Y":"Кожна позиція — рядок згори вниз.",
                "Радіально":"Кожна позиція — кільце шириною 1 піксель від центру всіх пікселів області."}[axis]
               + " Враховано лише пікселі всередині контуру.")
    st.line_chart(table[metrics], y_label="Температура, °C")
    with st.expander("Значення профілю"):
        st.dataframe(table[[*metrics, "Пікселів"]])

def differences(a, b, fields, metrics):
    rows = []
    for label in metrics:
        x, y = a.get(fields[label]), b.get(fields[label])
        d = abs(x-y) if pd.notna(x) and pd.notna(y) else None
        percent = 100*d/((x+y)/2+273.15) if d is not None else None
        rows.append({"Показник":label, "A, °C":x, "B, °C":y, "A − B, °C":x-y if d is not None else None,
                     "Абсолютна різниця, °C":d, "Відносна різниця, %":percent})
    return pd.DataFrame(rows)

def comparison(a, b, fields, key):
    metrics = st.multiselect("За якою температурою порівняти?", list(fields), default=["Мінімум", "Максимум", "Медіана"], key=key)
    if metrics:
        st.dataframe(differences(a, b, fields, metrics).round(3), hide_index=True)
        st.caption("Абсолютна різниця, °C = |A − B|: окремо для мінімальної, максимальної та медіанної температур. Вона завжди невід’ємна. Відносна різниця, % = 100 × |A − B| / ((A + B) / 2 + 273.15); база — середня температура двох областей у кельвінах. Порожня клітинка означає, що показник не збережено.")

def history_comparison(frame):
    if len(frame) < 2:
        return
    with st.expander("Порівняти два рядки таблиці"):
        def label(i):
            r = frame.loc[i]
            return f"{i+1}. {r['Учасник']} · {r['Ділянка']} · {r['Дата']} · {r['Сеанс']}"
        a = st.selectbox("Рядок A", list(frame.index), format_func=label)
        b = st.selectbox("Рядок B", [i for i in frame.index if i != a], format_func=label)
        comparison(frame.loc[a], frame.loc[b], HISTORY, "history_pair_metrics")
