"""Tab-scoped web history. Hydrate before any write; acknowledge every change."""
import hashlib
import json
import re
import streamlit as st

JS = r"""
const requests = new WeakMap();
export default function({data, setStateValue, parentElement}) {
    if (!data) return;
    const signature = data.request;
    if (requests.get(parentElement) === signature) return;
    requests.set(parentElement, signature);
    const key = "thermal-analysis:tab-history:v1";
    try {
        if (data.mode === "read") {
            const payload = sessionStorage.getItem(key) || "{}";
            setStateValue("reply", {request: signature, payload});
        } else {
            sessionStorage.setItem(key, data.payload);
            setStateValue("reply", {request: signature, saved: true});
        }
    } catch (error) {
        setStateValue("reply", {request: signature, error: error.name});
    }
}
"""
bridge = st.components.v2.component("thermal_tab_history", js=JS)


def validate_reports(payload):
    if not isinstance(payload, str) or len(payload) > 5_000_000:
        raise ValueError("Invalid history size")
    reports = json.loads(payload, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    if not isinstance(reports, dict):
        raise ValueError("Invalid history")
    for key, report in reports.items():
        if not isinstance(key, str) or not re.fullmatch(r"[0-9a-f]{64}", key):
            raise ValueError("Invalid record identifier")
        if not isinstance(report, dict) or report.get("schema_version") != 1 or not isinstance(report.get("regions"), list):
            raise ValueError("Invalid report")
        if any(not isinstance(region, dict) for region in report["regions"]):
            raise ValueError("Invalid region")
    return reports


def sync_tab_history():
    state = st.session_state
    hydrated = state.get("tab_history_ready", False)
    payload = json.dumps(state.get("public_reports", {}), ensure_ascii=False, allow_nan=False)
    request = "write:" + hashlib.sha256(payload.encode()).hexdigest() if hydrated else "read"
    reply = bridge(data={"mode": "write" if hydrated else "read", "request": request, "payload": payload if hydrated else None},
                   key="tab_history_bridge", on_reply_change=lambda: None, height=1).get("reply")
    if not reply or reply.get("request") != request:
        st.info("Відновлення історії вкладки…" if not hydrated else "Збереження історії у вкладці…")
        st.stop()
    if reply.get("error"):
        # Keep the live session usable if browser storage is blocked/full.
        state["tab_history_ready"] = True
        st.warning("Браузер не дозволив зберегти історію вкладки або сховище заповнене. Завантажте CSV: після оновлення останні зміни можуть зникнути.")
        return
    if not hydrated:
        try:
            restored = validate_reports(reply["payload"])
        except (ValueError, TypeError, KeyError):
            st.error("Збережена історія вкладки пошкоджена. Її не перезаписано.")
            st.stop()
        restored.update(state.get("public_reports", {}))
        state["public_reports"] = restored
        state["tab_history_ready"] = True
        st.rerun()
